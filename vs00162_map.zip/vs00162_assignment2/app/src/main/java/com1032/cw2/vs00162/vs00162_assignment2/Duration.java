package com1032.cw2.vs00162.vs00162_assignment2;

/**
 * Created by Vasily on 20/05/2016.
 */

/**
 * Class to define a Duration object.
 */
public class Duration {

    /**
     * Defining local variables.
     */
    public String text;
    public int value;

    /**
     * Creating parametrised constructor.
     */
    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
