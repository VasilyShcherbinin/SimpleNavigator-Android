package com1032.cw2.vs00162.vs00162_assignment2;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Vasily on 23/05/2016.
 */
public class About extends Activity {

    /**
     * Called when About is first created.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
